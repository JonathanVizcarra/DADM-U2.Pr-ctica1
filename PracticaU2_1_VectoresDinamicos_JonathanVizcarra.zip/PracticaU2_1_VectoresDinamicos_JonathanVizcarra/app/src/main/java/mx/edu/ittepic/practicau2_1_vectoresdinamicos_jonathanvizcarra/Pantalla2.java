package mx.edu.ittepic.practicau2_1_vectoresdinamicos_jonathanvizcarra;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class Pantalla2 extends AppCompatActivity {

    TableLayout tableLayout1;
    TableRow[] renglones = new TableRow[4];
    String[] valoresEtiquetas = {"Titulo","Fecha","Materia","Descripción"};
    String[] valoresHintCajas = {"Por ejemplo: DIAGRAMA UML", "En que debes entregar", "Quien la dejó", "Qué debo hacer"};
    TextView[] etiqueta = new TextView[4];
    EditText[] caja = new EditText[4];
    String[] datos;
    Button guardar;
    int posicion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla2);
        setTitle("CAPTURA DE TAREA");
        tableLayout1 = findViewById(R.id.tableLayout1);
        for (int i=0; i<4; i++){
            etiqueta[i] = new TextView(this);
            caja[i] = new EditText(this);
            renglones[i] = new TableRow(this);
            etiqueta[i].setText(valoresEtiquetas[i] + ":");
            caja[i].setHint(valoresHintCajas[i]);
            renglones[i].addView(etiqueta[i]);
            renglones[i].addView(caja[i]);
            renglones[i].setPadding(0,0,0,20);
            tableLayout1.addView(renglones[i]);
        }
        guardar = new Button(this);
        guardar.setText("GUARDAR");
        guardar.setPadding(0,40,0,40);
        caja[1].setInputType(InputType.TYPE_CLASS_DATETIME);
        tableLayout1.addView(guardar);

        guardar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (verificarDatos()){
                    try {
                        posicion = Integer.parseInt(datos[0]);
                        regresarDatos();
                    }catch (Exception e){pedirPosicion();}
                }
            }
        });

        llenarDatos();
    }

    private void llenarDatos() {
        try {
            datos = getIntent().getExtras().getStringArray("datos");
            for (int i=0; i<4; i++){
                caja[i].setText(datos[i + 1]);
            }
        }catch (Exception e){}
    }

    private void pedirPosicion() {
        AlertDialog.Builder mensaje = new AlertDialog.Builder(this);
        final EditText campo = new EditText(this);
        campo.setHint("Elige un numero entre 1 y 20");
        campo.setInputType(InputType.TYPE_CLASS_NUMBER);
        mensaje.setTitle("Posición")
                .setView(campo)
                .setMessage("Ingresa la posición en que deseas guardar tu tarea:")
                .setPositiveButton("Aceptar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        if (!campo.getText().toString().isEmpty()) {
                            try{
                                posicion = Integer.parseInt(campo.getText().toString());
                            }catch (Exception e){Toast.makeText(Pantalla2.this, "La posición no es valida", Toast.LENGTH_SHORT).show();}
                            if (posicion < 1 | posicion > 20) {
                                Toast.makeText(Pantalla2.this, "La posición no es valida", Toast.LENGTH_SHORT).show();
                            } else {
                                dialogInterface.dismiss();
                                posicion --;
                                regresarDatos();
                            }
                        }else{
                            Toast.makeText(Pantalla2.this, "La posición no es valida", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.cancel();
            }
        }).show();
    }

    private void regresarDatos() {
        String datosConcatenados = "";
        for (int i=0; i<4; i++){
            datosConcatenados += "&&" + caja[i].getText().toString();
        }
        Intent enviarDatos = new Intent();
        enviarDatos.putExtra("datos", posicion + datosConcatenados);
        enviarDatos.putExtra("posicion", posicion);
        setResult(1, enviarDatos);
        finish();
    }

    public boolean verificarDatos(){
        for(int i=0; i<4; i++){
            if(caja[i].getText().toString().replaceAll("\\s","").isEmpty()){
                Toast.makeText(this, "Necesitas ingresar "+valoresEtiquetas[i],Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }
}
