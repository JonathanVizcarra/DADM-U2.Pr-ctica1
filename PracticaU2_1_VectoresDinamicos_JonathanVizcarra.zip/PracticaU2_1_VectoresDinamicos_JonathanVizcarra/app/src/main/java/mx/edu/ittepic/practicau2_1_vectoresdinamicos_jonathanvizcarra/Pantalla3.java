package mx.edu.ittepic.practicau2_1_vectoresdinamicos_jonathanvizcarra;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.AndroidException;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class Pantalla3 extends AppCompatActivity {

    TableLayout tableLayout1;
    TableRow[] renglones = new TableRow[4];
    String[] valoresEtiquetas = {"Titulo","Fecha","Materia","Descripción"};
    TextView[] etiqueta = new TextView[4], etiquetaResultado = new TextView[4];
    Button[] boton = new Button[3];
    String[] datos;
    int posicion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla3);
        setTitle("DETALLE DE TAREA");
        tableLayout1 = findViewById(R.id.tableLayout1);
        datos = getIntent().getExtras().getString("datos").split("&&");
        posicion = Integer.parseInt(datos[0]);
        for (int i=0; i<4; i++){
            etiqueta[i] = new TextView(this);
            etiquetaResultado[i] = new TextView(this);
            renglones[i] = new TableRow(this);
            etiqueta[i].setText(valoresEtiquetas[i] + ":");
            etiquetaResultado[i].setText(datos[i+1]);
            etiquetaResultado[i].setPadding(20,0,0,0);
            etiquetaResultado[i].setTextColor(Color.RED);
            etiquetaResultado[i].setTextSize(20);
            renglones[i].addView(etiqueta[i]);
            renglones[i].addView(etiquetaResultado[i]);
            renglones[i].setPadding(0,0,0,20);
            tableLayout1.addView(renglones[i]);
        }
        TableLayout cajaBotones = new TableLayout(this);
        TableRow renglon = new TableRow(this);
        for (int i=0; i<3; i++){
            boton[i] = new Button(this);
            renglon.addView(boton[i]);
        }
        cajaBotones.addView(renglon);
        cajaBotones.setStretchAllColumns(true);
        tableLayout1.addView(cajaBotones);

        boton[0].setText("Borrar");
        boton[0].setCompoundDrawablesWithIntrinsicBounds(0, android.R.drawable.ic_menu_delete,0,0);
        boton[0].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder msj = new AlertDialog.Builder(Pantalla3.this);
                msj.setTitle("¡Atencion!").setMessage("¿Estas seguro que quieres borrar la tarea que se encuentra en la posición "+(posicion+1)+"?")
                        .setPositiveButton("Eliminar", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent enviarDatos = new Intent();
                                enviarDatos.putExtra("posicion", posicion);
                                setResult(2,enviarDatos);
                                dialogInterface.dismiss();
                                finish();
                            }
                        }).setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                }).show();
            }
        });
        boton[1].setText("Regresar");
        boton[1].setCompoundDrawablesWithIntrinsicBounds(0, android.R.drawable.ic_menu_revert,0,0);
        boton[1].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        boton[2].setText("Actualizar");
        boton[2].setCompoundDrawablesWithIntrinsicBounds(0, android.R.drawable.ic_menu_edit,0,0);
        boton[2].setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent llamarVentana = new Intent(Pantalla3.this, Pantalla2.class);
                llamarVentana.putExtra("datos", datos);
                startActivityForResult(llamarVentana, 3);
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        switch (resultCode){
            case 1:

                posicion = data.getIntExtra("posicion", 0);
                String datosConcatenados = data.getStringExtra("datos");
                datos = datosConcatenados.split("&&");
                for (int i=0; i<4; i++){
                    etiquetaResultado[i].setText(datos[i+1]);
                }
                Intent enviarDatos = new Intent();
                enviarDatos.putExtra("datos", datosConcatenados);
                enviarDatos.putExtra("posicion", posicion);
                setResult(1,enviarDatos);
                //finish();
                break;
            default:
                Toast.makeText(this,"No se realizó ninguna modificación", Toast.LENGTH_SHORT).show();
        }
    }

}
