package mx.edu.ittepic.practicau2_1_vectoresdinamicos_jonathanvizcarra;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class Pantalla1 extends AppCompatActivity {

    ListView listView1;
    String[] lista = new String[20];
    ArrayList listaDinamica;
    Intent llamarVentana;
    boolean estadoLista = false; //'true' si tiene datos | 'false' si está vacia

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla1);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                llamarVentana = new Intent(Pantalla1.this, Pantalla2.class);
                startActivityForResult(llamarVentana, 1);
            }
        });
        setTitle("TAREAS");
        listView1 = findViewById(R.id.listView1);
        crearLista();

        listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if (estadoLista){
                    llamarVentana = new Intent(Pantalla1.this, Pantalla3.class);
                    llamarVentana.putExtra("datos", listaDinamica.get(i).toString());
                    startActivityForResult(llamarVentana, 2);
                }else {
                    llamarVentana = new Intent(Pantalla1.this, Pantalla2.class);
                    startActivityForResult(llamarVentana, 1);
                }
            }
        });
    }

    private void crearLista() {
        if (!verificarLista()){
            estadoLista = true;
            String[] listaParaMostrar = new String[listaDinamica.size()];
            for (int i=0; i<listaDinamica.size(); i++){
                String[] datosSeparados = listaDinamica.get(i).toString().split("&&");
                listaParaMostrar[i] = datosSeparados[1];
            }
            listView1.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listaParaMostrar));
        }else {
            estadoLista = false;
            String[] mensaje = {"No hay tareas, agregue con el botón +"};
            ArrayAdapter<String> x = new ArrayAdapter<>(this,android.R.layout.simple_list_item_1, mensaje);
            listView1.setAdapter(x);
        }
    }

    private boolean verificarLista() {
        boolean vacio = true;
        listaDinamica = new ArrayList();
        for (int i=0; i<20; i++){
           if (!(lista[i] == null)){
               listaDinamica.add(lista[i]);
               vacio = false;
           }
        }
        return vacio;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_pantalla1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.opcion1) {
            AlertDialog.Builder msj = new AlertDialog.Builder(this);
            msj.setTitle("Acerca de...").setMessage("\nOctubre 2018 \n \n"+"Programado por: \nVizcarra Cabrales Jonathan Samuel \n" +
                    "\n Desarrollado en Android Studio").show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        int posicion;
        switch (resultCode){
            case 1:
                String datos = data.getStringExtra("datos");
                posicion = data.getIntExtra("posicion", 0);
                lista[posicion] = datos;
                break;
            case 2:
                posicion = data.getIntExtra("posicion", 0);
                lista[posicion] = null;
                break;
        }
        crearLista();
    }
}
